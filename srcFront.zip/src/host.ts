
export default {
  //https://qixingzhijia.szqws.com:8081/
    api:"http://localhost:8080/",name:"QiXingZhiJia" 
  };
  
